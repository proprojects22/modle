`2.0.4`
-------

**Fix:** The receipt does not contain order data

`2.0.3`
-------

- New: Attribute ``unit`` to display the product UoM on order receipt


`2.0.2`
-------

- FIX: Issue ``parentNode is undefined`` after order bill splitting


`2.0.1`
-------

- IMP: New function to increase the speed of order sending


`2.0.0`
-------

- NEW: New redefined functions


`1.0.0`
-------

- Init version
